package org.example.pltw.medialib;

/**
 * Created by baaka on 8/27/2017.
 */

public class Song {
    private int rating;
    private String title;

    /**
     * Constructor for objects of class Song
     */

    public Song()
    {
        // initialise instance variables
        rating = 0;
        title = "";
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String t) {
        title = t;
    }


}
