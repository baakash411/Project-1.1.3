package org.example.pltw.medialib;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView welcomeText = (TextView) findViewById(R.id.welcomeTextView);
;       Greeter greeter = new Greeter();
        welcomeText.setText(greeter.message);
    }

    /**
     * This method is called when the Show Contents button is clicked
     **/
    public void showMedia(View v) {

        TextView outputText = (TextView) findViewById(R.id.mediaLibText);

        //Song 2
        Song song1 = new Song("Song1", 2.99, 10);
        Movie movie1 = new Movie("Movie1", 10, 10);
        Books book1 = new Books("Book1", 10.0, 10);

        double totalCost = 0;
        int numSongs = 0;
        int totalRatings = 0;
        double averageCost;
        double averageRating;

        outputText.append("\n");
        outputText.append("Title: " + song1.getTitle());
        outputText.append("\n");
        outputText.append("Price: " + song1.getPrice());
        outputText.append("\n");
        outputText.append("Rating: " + song1.getRating());

        outputText.append("\n");
        outputText.append("Title: " + movie1.getTitle());
        outputText.append("\n");
        outputText.append("Price: " + movie1.getDuration());
        outputText.append("\n");
        outputText.append("Rating: " + movie1.getRating());

        outputText.append("\n");
        outputText.append("Title: " + book1.getTitle());
        outputText.append("\n");
        outputText.append("Price: " + book1.getPrice());
        outputText.append("\n");
        outputText.append("Rating: " + book1.getRating());

        /*
        Song song1 = new Song();
        System.out.println(song1);
        song1.setTitle("Songs: Numb");
        outputText.append("\n");
        outputText.append(song1.getTitle());

        outputText.append("\n");
        outputText.append(song1.getRating());
        outputText.


        Movie movie2 = new Movie();
        System.out.println(movie1);
        movie1.setTitle("Movies: Pepper");
        outputText.append("\n");
        outputText.append(movie1.getTitle());

        Books book2 = new Books();
        System.out.println(book1);
        book1.setTitle("Books: Treehouse");
        outputText.append("\n");
        outputText.append(book1.getTitle());

        Song song2 = new Song();
        System.out.println(song1);
        song1.setTitle("Songs: Warriors");
        outputText.append("\n");
        outputText.append(song1.getTitle());
        */
    }
}
