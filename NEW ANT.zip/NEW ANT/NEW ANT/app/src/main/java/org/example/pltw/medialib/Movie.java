package org.example.pltw.medialib;

/**
 * Created by baaka on 8/27/2017.
 */

public class Movie {
    private int rating;
    private String title;
    private int duration;
    private int minutes;
    private int hours;
    private double price;
    /**
     * Constructor for objects of class Song
     */
    public Movie()
    {
        rating = 0;
        title = "";
        duration = 0;
    }

    public Movie(String title, int rating, int duration) {
        this.title = title;
        this.rating = rating;
        this.duration = duration;
    }

    public String getTitle() {
        return title;
    }

    public int getRating() {
        return rating;
    }

    public int getDuration() {
        return duration;
    }

    public double getPrice() {
        return price;
    }


    public void setTitle(String t) {
        title = t;
    }

    public void setRating(int r) {
        rating = r;
    }

    public void setPrice(double p) {
        price = p;
    }

    public void setDuration(int d) {
        hours = (60 % d);
        minutes = (d % 60);
        System.out.println(hours + ":" + minutes);
    }

}
