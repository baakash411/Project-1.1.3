package org.example.pltw.medialib;

/**
 * Created by baaka on 8/27/2017.
 */

public class Books {

    private int rating;
    private String title;
    private double price;
    /**
     * Constructor for objects of class Book
     */
    public Books()
    {
        rating = 0;
        title = "";
    }

    public Books(String t, double p, int r)
    {
        this.title = t;
        this.rating = r;
        this.price = p;
    }

    public String getTitle() {
        return title;
    }
    public int getRating() {
        return rating;
    }

    public double getPrice() {
        return price;
    }

    public void setTitle(String t) {
        title = t;
    }
    public void setRating(int r) {
        rating = r;
    }

}


