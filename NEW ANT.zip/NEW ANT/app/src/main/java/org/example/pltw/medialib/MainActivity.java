package org.example.pltw.medialib;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView welcomeText = (TextView) findViewById(R.id.welcomeTextView);
;       Greeter greeter = new Greeter();
        welcomeText.setText(greeter.message);
    }

    /**
     * This method is called when the Show Contents button is clicked
     **/
    public void showMedia(View v) {

        TextView outputText = (TextView) findViewById(R.id.mediaLibText);


        Movie movie1 = new Movie();
        System.out.println(movie1);
        movie1.setTitle("Movies: Salt");
        outputText.append("\n");
        outputText.append(movie1.getTitle());

        Books book1 = new Books();
        System.out.println(book1);
        book1.setTitle("Books: Harry Potter");
        outputText.append("\n");
        outputText.append(book1.getTitle());

        Song song1 = new Song();
        System.out.println(song1);
        song1.setTitle("Songs: Numb");
        outputText.append("\n");
        outputText.append(song1.getTitle());


        Movie movie2 = new Movie();
        System.out.println(movie1);
        movie1.setTitle("Movies: Pepper");
        outputText.append("\n");
        outputText.append(movie1.getTitle());

        Books book2 = new Books();
        System.out.println(book1);
        book1.setTitle("Books: Treehouse");
        outputText.append("\n");
        outputText.append(book1.getTitle());

        Song song2 = new Song();
        System.out.println(song1);
        song1.setTitle("Songs: Warriors");
        outputText.append("\n");
        outputText.append(song1.getTitle());
    }
}
