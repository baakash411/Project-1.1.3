package org.example.pltw.medialib;

/**
 * Created by baaka on 8/27/2017.
 */

public class Books {

    private int rating;
    private String title;




    public Books()
    {
        // initialise instance variables
        rating = 0;
        title = "";
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String t) {
        title = t;
    }
}


