
/**
 * Write a description of class WeatherConditionals here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WeatherConditionals
{
    //new method getWeatherAdvice
    public static String getWeatherAdvice(int temperature, String description) 
    {
        //tells the user what the temperature is in degrees and what the weather is going to be like 
        boolean windy = false;
        boolean sunny = false;
        boolean snow = false;
        
        
        //Change the boolean value depending on the description. 
        if (description.equals("windy")) {
            windy = true;
        }
        if (description.equals("sunny")) {
            sunny = true; 
        }
        if (description.equals("snow")) {
            snow = true; 
        }
        
        //Printing out statements 
        if (temperature > 30 && temperature < 100) {
            System.out.println("It is safe to go outside," + temperature + " degrees and " + description); 
        } else if(temperature >= 100 && description == "snow"){
            System.out.println("What the heck my dude. That's not a valid report.");
        } else {
            System.out.println("Too windy or too cold! Enjoy watching the weather from the window!");
        }
        
        return temperature + description;
        
    }
    
    //new method getHikingAdvice
    public static String getHikingAdvice(int temperature, int windchill, 
    int humidity, String description){
        
        if (temperature >= 65 && description == "cloudy" || description == "Cloudy" || description == "CLOUDY")
        {
            
            System.out.println("You're in San Jose");
        } else if (description == "fair" || description == "Fair" || description == "FAIR") {
            
            System.out.println("You're in Santa Fe");
        } else if (windchill < 10 && humidity == 70) {
            
            System.out.println("You're in Hong Kong");
        } else if (windchill == 50 && temperature == 10) {
            
            System.out.println("You're in Mt Everest");
        } else if (temperature >= 40 && windchill == 0) {
            
            System.out.println("You're on the moon");
        } else {
            
            System.out.println("Bring an Umbrella");
        }
        
        
        return temperature + windchill + humidity + description; 
    }
}
