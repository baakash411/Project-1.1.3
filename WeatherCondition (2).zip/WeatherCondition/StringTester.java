
/**
 * Write a description of class StringTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class StringTester
{
    // instance variables - replace the example below with your own
    public static void main(String[] args) {
        
        String weatherCondition = new String("mixed rain and snow");
        
        WeatherConditionals.getWeatherAdvice(32, "sunny");
        
        WeatherConditionals.getHikingAdvice(65, 10,  10, "CLOUDY");
        
        WeatherConditionals.getHikingAdvice(5, 5, 5, "fair");
        
        WeatherConditionals.getHikingAdvice(40, 5, 70, "hot");
        
        WeatherConditionals.getHikingAdvice(10, 50, 10, "Mountain");
        
        WeatherConditionals.getHikingAdvice(40, 0, 0, "space");
        //Step 16
        /*
        System.out.println(WeatherConditionals.getWeatherAdvice(32, "heavy snow"));
        
        System.out.println(weatherCondition.length());
        
        
        WeatherConditionals.getWeatherAdvice(34, "sunny");
        WeatherConditionals.getWeatherAdvice(32, "windy");
        WeatherConditionals.getWeatherAdvice(33, "snow");
        WeatherConditionals.getWeatherAdvice(30, "snow");
        WeatherConditionals.getWeatherAdvice(30, "windy");
        WeatherConditionals.getWeatherAdvice(100, "snow");
        */
    }
}
