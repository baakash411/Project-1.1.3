
/**
 * Write a description of class MediaLib here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MediaLib
{
    public static void main (String[] args) 
    {
        System.out.println("Welcome to your Media Library!");
        
        Song song1 = new Song();
        System.out.println(song1);
        
        song1.setTitle("Johnny B. Goode");
        System.out.println(song1.getTitle());
        
        song1.setRating(10);
        System.out.println(song1.getRating());
        
        song1.setPrice(0.99);
        System.out.println(song1.getPrice());
        
        Song song2 = new Song("Song2", 2.99, 10);
        Song song3 = new Song("Song3", 1.29, 10);
        Song song4 = new Song("Song4", 0.99, 8);
        Song song5 = new Song("Song5", 1.29, 9);
        Song song6 = new Song("Song6", 2.00, 9);
        Song song7 = new Song("Song7", 1.50, 9);
        Song song8 = new Song("Song8", 1.28, 9);
    }
}
