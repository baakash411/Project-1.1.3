
/**
 * Write a description of class WeatherConditionals here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WeatherConditionals
{
    //new method getWeatherAdvice
    public static String getWeatherAdvice(int temperature, int windchill, int humidity, String description) 
    {
        //tells the user what the temperature is in degrees and what the weather is going to be like 
        boolean windy = false;
        boolean sunny = false;
        boolean snow = false;
        
        if (description.equals("windy")) {
            windy = true;
        }
        if (description.equals("sunny")) {
            sunny = true; 
        }
        if (description.equals("snow")) {
            snow = true; 
        }
        
        if (temperature > 30 && temperature < 100) {
            System.out.println("It is safe to go outside," + temperature + " degrees and " + description); 
        } else if(temperature >= 100 && description == "snow"){
            System.out.println("What the heck my dude. That's not a valid report.");
        } else {
            System.out.println("Too windy or too cold! Enjoy watching the weather from the window!");
        }
        
        return temperature + description;
        
    }
}
