package org.example.pltw.medialib;

/**
 * Created by baaka on 8/27/2017.
 */

public class Greeter {
    public String message = "Welcome to your Media Library";
}
